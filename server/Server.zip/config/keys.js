module.exports = {
    secretOrKey: 'secret',
};

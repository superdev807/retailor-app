export { default } from './ApartmentsTable';

import { colors } from '@material-ui/core';

export default {
  root: {
    backgroundColor: colors.grey[50]
  }
};

export { default } from './Minimal';

import { makeStyles } from '@material-ui/styles';
export const useStyles = makeStyles((theme) => ({
    center: {
        display: 'flex',
        alignItems: 'center',
        height: '100%',
        justifyContent: 'center',
    },
}));
